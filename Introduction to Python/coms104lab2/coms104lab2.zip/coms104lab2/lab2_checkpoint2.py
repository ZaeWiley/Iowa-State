print "Hello World"

print "Hello" , "World"

print "Hello" + "World"

print "Hello"
print "World"

print "World"
print "Hello"
