# Simple interactive script figures out a person's age # in dog years
name = raw_input("What's your name? ")
print "Customer's full name: ", name
nights = input("How many nights are you staying? ")
print "Number of nights:  ", nights
Totalroomservicecharge = 135
print "Room service costs for you will be $135"
Totaltelephonecharge = 12.5
print "Your telephone bill will be $12.50"
print "Calculating..."
print "Calculating..."
print "River bend Hotel Bill Customer: ", name
totalroomcharge = 55*nights
print "Total room charge($): " ,totalroomcharge
entertainmenttax = 16.5
print "Entertainment tax($): " ,entertainmenttax
totalbill = totalroomcharge+Totalroomservicecharge+Totaltelephonecharge+entertainmenttax
print "Total Bill($): " ,totalbill
